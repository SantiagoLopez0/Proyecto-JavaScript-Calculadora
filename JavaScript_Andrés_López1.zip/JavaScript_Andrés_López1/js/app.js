var Calculadora = {
	init: function()
	{
		this.modificarTeclasPrimeraFila();
		this.modificarTeclasSegundaFila();
		this.darNumerosDisplay();
	},
	modificarTeclasPrimeraFila: function()
	{
		document.querySelectorAll(".teclado img")[0].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[0].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[0].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[0].style.width="22%";	
		}
		
		document.querySelectorAll(".teclado img")[1].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[1].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[1].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[1].style.width="22%";	
		}
		
		document.querySelectorAll(".teclado img")[2].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[2].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[2].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[2].style.width="22%";	
		}
		
		document.querySelectorAll(".teclado img")[3].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[3].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[3].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[3].style.width="22%";	
		}
		
		document.querySelectorAll(".teclado img")[4].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[4].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[4].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[4].style.width="22%";	
		}
		
		document.querySelectorAll(".teclado img")[5].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[5].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[5].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[5].style.width="22%";	
		}
		
		document.querySelectorAll(".teclado img")[6].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[6].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[6].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[6].style.width="22%";	
		}
		
		document.querySelectorAll(".teclado img")[7].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[7].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[7].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[7].style.width="22%";	
		}
		
		document.querySelectorAll(".teclado img")[8].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[8].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[8].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[8].style.width="22%";	
		}
		
		document.querySelectorAll(".teclado img")[9].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[9].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[9].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[9].style.width="22%";	
		}
		
		document.querySelectorAll(".teclado img")[10].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[10].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[10].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[10].style.width="22%";	
		}
		
		document.querySelectorAll(".teclado img")[11].onmousedown = function()
		{
			document.querySelectorAll(".teclado img")[11].style.width="20%";		
		}
		document.querySelectorAll(".teclado img")[11].onmouseup = function()
		{
			document.querySelectorAll(".teclado img")[11].style.width="22%";	
		}
	},
	modificarTeclasSegundaFila: function()
	{
		document.querySelectorAll(".teclado .row .col1 img")[0].onmousedown = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[0].style.width="27%";		
		}
		document.querySelectorAll(".teclado .row .col1 img")[0].onmouseup = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[0].style.width="29%";	
		}
		
		document.querySelectorAll(".teclado .row .col1 img")[1].onmousedown = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[1].style.width="27%";		
		}
		document.querySelectorAll(".teclado .row .col1 img")[1].onmouseup = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[1].style.width="29%";	
		}
		
		document.querySelectorAll(".teclado .row .col1 img")[2].onmousedown = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[2].style.width="27%";		
		}
		document.querySelectorAll(".teclado .row .col1 img")[2].onmouseup = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[2].style.width="29%";	
		}
		
		document.querySelectorAll(".teclado .row .col1 img")[3].onmousedown = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[3].style.width="27%";		
		}
		document.querySelectorAll(".teclado .row .col1 img")[3].onmouseup = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[3].style.width="29%";	
		}
		
		document.querySelectorAll(".teclado .row .col1 img")[4].onmousedown = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[4].style.width="27%";		
		}
		document.querySelectorAll(".teclado .row .col1 img")[4].onmouseup = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[4].style.width="29%";	
		}
		
		document.querySelectorAll(".teclado .row .col1 img")[5].onmousedown = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[5].style.width="27%";		
		}
		document.querySelectorAll(".teclado .row .col1 img")[5].onmouseup = function()
		{
			document.querySelectorAll(".teclado .row .col1 img")[5].style.width="29%";	
		}
		
		document.getElementById("mas").onmousedown = function()
		{
			document.getElementById("mas").style.width="85%";		
		}
		document.getElementById("mas").onmouseup = function()
		{
			document.getElementById("mas").style.width="100%";	
		}
	},
	objeto: {
		numero1: 1,
		numero2: 2,
		teclas: document.getElementsByClassName("tecla"),
		display: document.getElementById("display"),
		darMensaje: function()
		{
			var numero = 2; 
			var newDiv = document.createElement("span"); 
			display.append(newDiv);
			var newContent = document.createTextNode(numero1); 
			newDiv.appendChild(newContent); 
		}
	},
	darMensaje: function(i)
	{
		var parametro = i; 
		var newDiv = document.createElement("span"); display.append(newDiv); 
		var newContent = document.createTextNode(parametro); 
		newDiv.appendChild(newContent);
	},
	darNumerosDisplay()
	{
		var teclas = document.getElementsByClassName("tecla");
		teclas[4].onclick = function(){darMensaje(7)};
	}
	
}
Calculadora.init();


